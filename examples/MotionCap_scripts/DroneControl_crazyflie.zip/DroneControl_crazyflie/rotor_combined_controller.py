import numpy as np 
import time
import threading

class rotor_combined_controller():
	"""docstring for rotor_combined_controller"""
	def __init__(self):
		self.beta_offset= 0.15
		self.thrust 	= np.zeros(4)
		self.mass 		= 0.15
		self.gravity 	= np.array([0, 0, -9.8])
		self.inertia 	= np.diag([0.001417, 0.001417, 0.002738])
		self.arm_length = 0.14
		self.rot_matrix = np.mat(np.diag([1,1,1]))
		self.jacobian_alpha = np.zeros((3,4))
		self.jacobian_acc 	= np.zeros((3,4))
		self.jacobian_beta = np.matrix([[0, -2, 0, -1, 0],
										[-2, 0, 0, 0, 1],
										[0, 2, 0, 1, 0],
										[2, 0, 0, 0, -1]]).T

		# Controller Gains
		self.K_att_int	= np.array([5, 5, 0])*3
		self.K_att 		= np.array([30, 25, 10])*3
		self.K_att_dot 	= np.array([8, 8, 2])*3

		self.Kxint 		= np.array([2, 2, 10])
		self.Kx 		= np.array([20, 20, 30])
		self.Kv 		= np.array([20, 20, 5])
		self.f_c_max 	= 5

		self.K_att_intergrater 	= 0
		self.K_att_max 			= 50
		self.Kx_intergrater 	= 0
		self.Kx_int_max 		= 20

		# Control Inputs
		self.quaternion		= np.array([1,0,0,0])
		self.agv 			= np.zeros(3)
		self.pos 			= np.zeros(3)
		self.vel 			= np.zeros(3)
		self.euler_setpoint	= np.zeros(3)
		self.pos_setpoint	= np.zeros(3)

		# Control Signals & Measuremnets
		self.att_ref	= np.zeros(3)
		self.agv_ref 	= np.zeros(3)
		self.pos_ref 	= np.zeros(3)
		self.vel_ref 	= np.zeros(3)

		self.att_mea	= np.zeros(3)
		self.agv_mea 	= np.zeros(3)
		self.pos_mea 	= np.zeros(3)
		self.vel_mea 	= np.zeros(3)

		# Controller_outputs
		self.tau_c 		= np.zeros(3)
		self.f_c 		= np.zeros(3)
		self.thrust 	= np.zeros(4)
		self.beta 		= np.zeros(4)

		self.last_update= time.time()
		self.dt 		= 0
		self.stop_controller 	= False
		self.log 		= []

	def update_states(self):
		phi = np.arctan2(2*(self.quaternion[0]*self.quaternion[1]+self.quaternion[2]*self.quaternion[3]),(1-2*(self.quaternion[1]*self.quaternion[1]+self.quaternion[2]*self.quaternion[2])))
		theta = np.arcsin(2*(self.quaternion[0]*self.quaternion[2]-self.quaternion[3]*self.quaternion[1]))
		psi = np.arctan2(2*(self.quaternion[0]*self.quaternion[3]+self.quaternion[1]*self.quaternion[2]),(1-2*(self.quaternion[2]*self.quaternion[2]+self.quaternion[3]*self.quaternion[3])))
		
		self.att_mea = np.array([phi, theta, psi])
		self.agv_mea = np.asarray(self.agv)
		self.pos_mea = np.asarray(self.pos)
		self.vel_mea = np.asarray(self.vel)

	def update_setpoints(self, euler_setpoint, pos_setpoint):
		self.att_ref = np.asarray(euler_setpoint)
		self.pos_ref = np.asarray(pos_setpoint)

	def update_jacobian_matrix(self):
		self.jacobian_alpha = self.arm_length * np.transpose(np.matrix([[-np.cos(self.beta[0]), 0, np.cos(self.beta[2]), 0],
																	    [0, np.cos(self.beta[1]), 0, -np.cos(self.beta[3])],
																	    [np.sin(self.beta[0]), np.sin(self.beta[1]), np.sin(self.beta[2]), np.sin(self.beta[3])]]))

		self.jacobian_acc 	= np.transpose(np.matrix([[-np.sin(self.beta[0]), 0, np.sin(self.beta[2]), 0],
													  [0, np.sin(self.beta[1]), 0, -np.sin(self.beta[3])],
													  [-np.cos(self.beta[0]), -np.cos(self.beta[1]), -np.cos(self.beta[2]), -np.cos(self.beta[3])]])) * np.transpose(self.rot_matrix)

	def att_controller_step(self):
		att_err = self.att_ref - self.att_mea
		agv_err = self.agv_ref - self.agv_mea
		self.K_att_intergrater = np.clip(self.K_att_intergrater + att_err*self.dt, -self.K_att_max, self.K_att_max)

		self.tau_c = np.squeeze(np.matmul((self.K_att*att_err + self.K_att_dot*agv_err + self.K_att_int*self.K_att_intergrater), self.inertia))

	def pos_controller_step(self):
		pos_err = self.pos_ref - self.pos_mea
		vel_err = self.vel_ref - self.vel_mea
		self.Kx_intergrater = np.clip(self.Kx_intergrater + pos_err*self.dt, -self.Kx_int_max, self.Kx_int_max)

		self.f_c = np.clip(self.mass*(self.Kx*pos_err + self.Kv*vel_err + self.Kxint*self.Kx_intergrater + self.gravity), -self.f_c_max, self.f_c_max)

	def step(self):
		current_time = time.time()
		self.dt = current_time- self.last_update
		self.log.append(self.dt)
		self.update_states()
		self.update_setpoints(self.euler_setpoint, self.pos_setpoint)
		self.att_controller_step()
		self.pos_controller_step()
		thrust_states 	= np.concatenate((self.tau_c, [self.f_c[2]]), axis=0)
		beta_states 	= np.concatenate((self.euler_setpoint, 0.1*np.arctan(self.f_c[0:2])), axis=0)
		self.beta = np.asarray(np.matmul(beta_states, self.jacobian_beta) + np.array([self.beta_offset, -self.beta_offset, self.beta_offset, -self.beta_offset]))[0]

		self.update_jacobian_matrix()
		jacobian 		= np.concatenate((self.jacobian_alpha, self.jacobian_acc[:,2]), axis=1)
		self.thrust = np.asarray(np.matmul(thrust_states, np.linalg.pinv(jacobian)))[0]

		self.last_update = current_time

	def run(self):
		last_loop_time = time.time()
		while not self.stop_controller:
			if time.time() - last_loop_time > 0.005:
				self.step()
				last_loop_time = time.time()
				time.sleep(0.003)
			else:
				time.sleep(0.001)
		# print(self.log)


if __name__ == '__main__':
	controller = rotor_combined_controller()

	control_thread = threading.Thread(target=controller.run, name='T1')
	tic = time.time()
	control_thread.start()
	toc = time.time()

	for x in range(1,1000):
		pass
		# print (controller.thrust, controller.beta)
	controller.stop_controller = True

	print(toc-tic)



