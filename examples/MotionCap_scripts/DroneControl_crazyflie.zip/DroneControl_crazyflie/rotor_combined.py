# -*- coding: utf-8 -*-
#
#     ||          ____  _ __
#  +------+      / __ )(_) /_______________ _____  ___
#  | 0xBC |     / __  / / __/ ___/ ___/ __ `/_  / / _ \
#  +------+    / /_/ / / /_/ /__/ /  / /_/ / / /_/  __/
#   ||  ||    /_____/_/\__/\___/_/   \__,_/ /___/\___/
#
#  Copyright (C) 2014 Bitcraze AB
#
#  Crazyflie Nano Quadcopter Client
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
#  MA  02110-1301, USA.
"""
Simple example that connects to the first Crazyflie found, ramps up/down
the motors and disconnects.
"""
import sys, os
import logging
import time
import math
import numpy as np
from threading import Thread
from keyboard import keyboard_control
from Optitrack import OptiTrack
from rotor_combined_controller import rotor_combined_controller
from rotor_combined_logger import rotor_combined_logger

import cflib
from cflib.crazyflie import Crazyflie
from cflib.crazyflie.log import LogConfig

logging.basicConfig(level=logging.ERROR)

class MeasureQuad:
    """Example that connects to a Crazyflie and ramps the motors up/down and
    the disconnects"""

    def __init__(self, link_uri):
        """ Initialize and run the example with the specified link_uri """

        self._cf = Crazyflie(rw_cache='./cache')

        self._cf.connected.add_callback(self._connected)
        self._cf.disconnected.add_callback(self._disconnected)
        self._cf.connection_failed.add_callback(self._connection_failed)
        self._cf.connection_lost.add_callback(self._connection_lost)

        self._cf.open_link(link_uri)

        print('Connecting to MeasureQuad %s' % link_uri)

        self.base_q = np.array([1,0,0,0])
        self.base_q_prev = np.array([1,0,0,0])
        self.base_q_rate = np.array([0,0,0])
        self.base_pos = np.array([0,0,0])
        self.stop_loop = False
        self.update_time = time.time()
        self.omega_array = np.zeros((3,3))
    
    def _connected(self, link_uri):
        # The definition of the logconfig can be made before connecting
        self._lg_stab = LogConfig(name='stateEstimate', period_in_ms=10)
        self._lg_stab.add_variable('stateEstimate.qw', 'float')
        self._lg_stab.add_variable('stateEstimate.qx', 'float')
        self._lg_stab.add_variable('stateEstimate.qy', 'float')
        self._lg_stab.add_variable('stateEstimate.qz', 'float')
        # self._lg_stab.add_variable('ext_pos.X', 'float')
        # self._lg_stab.add_variable('ext_pos.Y', 'float')
        # self._lg_stab.add_variable('ext_pos.Z', 'float')

        # Adding the configuration cannot be done until a Crazyflie is
        # connected, since we need to check that the variables we
        # would like to log are in the TOC.
        try:
            self._cf.log.add_config(self._lg_stab)
            # This callback will receive the data
            self._lg_stab.data_received_cb.add_callback(self._stab_log_data)
            # This callback will be called on errors
            self._lg_stab.error_cb.add_callback(self._stab_log_error)
            # Start the logging
            self._lg_stab.start()
        except KeyError as e:
            print('Could not start log configuration,'
                  '{} not found in TOC'.format(str(e)))
        except AttributeError:
            print('Could not add Stabilizer log config, bad configuration.')
        pass

    def _stab_log_error(self, logconf, msg):
        """Callback from the log API when an error occurs"""
        print('Error when logging %s: %s' % (logconf.name, msg))

    def _stab_log_data(self, timestamp, data, logconf):
        """Callback froma the log API when data arrives"""
        current_time = time.time()
        self.base_q = np.array([data["stateEstimate.qw"], data["stateEstimate.qx"], -data["stateEstimate.qy"], -data["stateEstimate.qz"]])
        self.base_q_rate = self.omega(self.base_q, self.base_q_prev, current_time-self.update_time)
        self.base_q_prev = self.base_q
        self.update_time = current_time
        # print(self.base_q_rate)
        # print('[%d][%s]: %s' % (timestamp, logconf.name, data["stateEstimate.qw"]))

    def _connection_failed(self, link_uri, msg):
        """Callback when connection initial connection fails (i.e no Crazyflie
        at the specified address)"""
        print('Connection to %s failed: %s' % (link_uri, msg))

    def _connection_lost(self, link_uri, msg):
        """Callback when disconnected after a connection has been made (i.e
        Crazyflie moves out of range)"""
        print('Connection to %s lost: %s' % (link_uri, msg))

    def _disconnected(self, link_uri):
        """Callback when the Crazyflie is disconnected (called in all cases)"""
        print('Disconnected from %s' % link_uri)

    def omega(self, quaternion, quaternion_prev, dt):
        dq = (quaternion - quaternion_prev) / dt
        w, x, y, z = quaternion
        omega = 2 * np.mat([[w, x, y, z],
                            [-x, w, z, -y],
                            [-y, -z, w, x],
                            [-z, y, -x, w]]) * np.vstack(dq)
        return np.asarray(omega[1:4]).reshape(-1)

    # def omega(self, quaternion, quaternion_prev, dt):
    #     dq = (quaternion - quaternion_prev) / dt
    #     w, x, y, z = quaternion
    #     omega = 2 * np.mat([[w, x, y, z],
    #                         [-x, w, z, -y],
    #                         [-y, -z, w, x],
    #                         [-z, y, -x, w]]) * np.vstack(dq)
    #     self.omega_array = np.array([np.asarray(omega[1:4]).reshape(-1)*0.9, self.omega_array[0]*0.07, self.omega_array[1]*0.03])
    #     return np.sum(self.omega_array, axis=0)

    def _stop_crazyflie(self):
        self.stop_loop = True
        self._cf.commander.send_stop_setpoint()
        time.sleep(0.1)
        self._cf.close_link()

class MotorRampExample:
    """Example that connects to a Crazyflie and ramps the motors up/down and
    the disconnects"""

    def __init__(self, link_uri, index):
        """ Initialize and run the example with the specified link_uri """

        self._cf = Crazyflie(rw_cache='./cache')

        self._cf.connected.add_callback(self._connected)
        self._cf.disconnected.add_callback(self._disconnected)
        self._cf.connection_failed.add_callback(self._connection_failed)
        self._cf.connection_lost.add_callback(self._connection_lost)

        self._cf.open_link(link_uri)

        print('Connecting to %s' % link_uri)

        self.index = index
        self.theta_meas = 0
        self.theta = 0
        self.thrust = 0
        self.base_q = np.array([1,0,0,0])
        self.quad_q = np.array([1,0,0,0])
        self.stop_loop = False

    def _connected(self, link_uri):
        # The definition of the logconfig can be made before connecting
        self._lg_stab = LogConfig(name='Q_att', period_in_ms=10)
        self._lg_stab.add_variable('Q_att.theta_meas', 'float')

        # Adding the configuration cannot be done until a Crazyflie is
        # connected, since we need to check that the variables we
        # would like to log are in the TOC.
        try:
            self._cf.log.add_config(self._lg_stab)
            # This callback will receive the data
            self._lg_stab.data_received_cb.add_callback(self._stab_log_data)
            # This callback will be called on errors
            self._lg_stab.error_cb.add_callback(self._stab_log_error)
            # Start the logging
            self._lg_stab.start()
        except KeyError as e:
            print('Could not start log configuration,'
                  '{} not found in TOC'.format(str(e)))
        except AttributeError:
            print('Could not add Stabilizer log config, bad configuration.')
        pass

    def _stab_log_error(self, logconf, msg):
        """Callback from the log API when an error occurs"""
        print('Error when logging %s: %s' % (logconf.name, msg))

    def _stab_log_data(self, timestamp, data, logconf):
        """Callback froma the log API when data arrives"""
        # print('[%d][%s]: %s' % (timestamp, logconf.name, data))
        self.theta_meas = data["Q_att.theta_meas"]

    def _connection_failed(self, link_uri, msg):
        """Callback when connection initial connection fails (i.e no Crazyflie
        at the specified address)"""
        print('Connection to %s failed: %s' % (link_uri, msg))

    def _connection_lost(self, link_uri, msg):
        """Callback when disconnected after a connection has been made (i.e
        Crazyflie moves out of range)"""
        print('Connection to %s lost: %s' % (link_uri, msg))

    def _disconnected(self, link_uri):
        """Callback when the Crazyflie is disconnected (called in all cases)"""
        print('Disconnected from %s' % link_uri)

    def _update_motors(self):
        self._cf.commander.send_base_pose(self.index, 
                                          self.base_q[0], 
                                          self.base_q[1], 
                                          self.base_q[2], 
                                          self.base_q[3], 
                                          self.theta, 
                                          self.thrust)
            # time.sleep(0.01)

    def _stop_crazyflie(self):
        self.stop_loop = True
        self._cf.commander.send_stop_setpoint()
        # time.sleep(0.1)
        self._cf.close_link()

class rotor_combined:
    """docstring for rotor_combined"""
    def __init__(self, folder_name='log_files', keyboard_mode='attitude'):
        # Initialize the low-level drivers (don't list the debug drivers)
        cflib.crtp.init_drivers(enable_debug_driver=False)
        # Scan for Crazyflies and use the first one found
        print('Scanning interfaces for Crazyflies...')
        # available = cflib.crtp.scan_interfaces()
        # print('Crazyflies found:')
        time.sleep(0.25)

        self.op = OptiTrack()
        # self.measureQuad = MeasureQuad('radio://0/120/2M/E7E7E7E7E6')
        time.sleep(0.25)

        self.rotor0 = MotorRampExample('radio://1/80/2M/E7E7E7E7E7', 0)
        time.sleep(0.25)
        self.rotor1 = MotorRampExample('radio://2/100/2M/E7E7E7E7E8', 1)
        time.sleep(0.25)
        self.rotor2 = MotorRampExample('radio://1/80/2M/E7E7E7E7E9', 2)
        time.sleep(0.25)
        self.rotor3 = MotorRampExample('radio://2/100/2M/E7E7E7E7EA', 3)
        time.sleep(0.25)


        self.remoter = keyboard_control(control_mode=keyboard_mode)
        self.logger = rotor_combined_logger(folder_name=folder_name)
        self.controller = rotor_combined_controller()

        self.start_time = time.time()
        self.prev_time = time.time()

        self.control_thread = Thread(target=self.controller.run, name='T1')
        self.input_update_thread = Thread(target=self.update_controller, name='T2')

    def run(self):
        current_time = time.time()
        self.remoter.command.update()

        self.logger.log_append(int(round((current_time - self.start_time) * 1000)),
                               int(round((current_time-self.prev_time) * 1000)),
                               self.controller.agv_mea[0],
                               self.controller.agv_mea[1],
                               self.controller.agv_mea[2],
                               self.controller.att_mea[0]*180/math.pi,
                               self.controller.att_mea[1]*180/math.pi,
                               self.controller.att_mea[2]*180/math.pi,
                               self.controller.vel_mea[0],
                               self.controller.vel_mea[1],
                               self.controller.vel_mea[2],
                               self.controller.pos_mea[0],
                               self.controller.pos_mea[1],
                               self.controller.pos_mea[2],
                               self.remoter.roll*180/math.pi,
                               self.remoter.pitch*180/math.pi,
                               self.remoter.yaw*180/math.pi,
                               self.remoter.x,
                               self.remoter.y,
                               self.remoter.z,
                               self.rotor0.theta_meas,
                               self.rotor1.theta_meas,
                               self.rotor2.theta_meas,
                               self.rotor3.theta_meas,
                               self.controller.thrust[0],
                               self.controller.thrust[1],
                               self.controller.thrust[2],
                               self.controller.thrust[3],
                               self.controller.beta[0],
                               self.controller.beta[1],
                               self.controller.beta[2],
                               self.controller.beta[3])

        self.set_setpoint(self.op.rotation, self.controller.beta, self.controller.thrust)
        # self.set_setpoint(np.array([1,0,0,0]), [0,0,0,0], [0,0,0,0])

        self.prev_time = current_time

    def update_controller(self):
        while not self.remoter.stop:
            # self.controller.quaternion      = self.measureQuad.base_q
            # self.controller.agv             = self.measureQuad.base_q_rate
            # self.controller.pos             = [0,0,0]
            # self.controller.vel             = [0,0,0]
            self.controller.quaternion      = self.op.rotation
            self.controller.agv             = self.op.rotation_rate
            self.controller.pos             = self.op.position
            self.controller.vel             = self.op.velocity
            self.controller.euler_setpoint  = [self.remoter.roll, self.remoter.pitch, 0]
            self.controller.pos_setpoint    = [self.remoter.x, self.remoter.y, self.remoter.z]
            # time.sleep(0.001)

    def set_setpoint(self, quaternion, beta, thrust):
        self.rotor0.theta = beta[0]
        self.rotor0.thrust = thrust[0]
        self.rotor0.base_q = quaternion
        self.rotor0._update_motors()
        # time.sleep(0.001)
        
        self.rotor1.theta = beta[1]
        self.rotor1.thrust = thrust[1]
        self.rotor1.base_q = quaternion
        self.rotor1._update_motors()
        # time.sleep(0.001)

        self.rotor2.theta = beta[2]
        self.rotor2.thrust = thrust[2]
        self.rotor2.base_q = quaternion
        self.rotor2._update_motors()
        # time.sleep(0.001)

        self.rotor3.theta = beta[3]
        self.rotor3.thrust = thrust[3]
        self.rotor3.base_q = quaternion
        self.rotor3._update_motors()
        # time.sleep(0.001)

        # thread0 = Thread(target=self.rotor0._update_motors)
        # thread1 = Thread(target=self.rotor1._update_motors)
        # thread2 = Thread(target=self.rotor2._update_motors)
        # thread3 = Thread(target=self.rotor3._update_motors)
        # thread0.start()
        # thread1.start()
        # thread2.start()
        # thread3.start()
        # thread3.join()
        # thread2.join()
        # thread1.join()
        # thread0.join()

    def stop_frame(self):
        # self.measureQuad._stop_crazyflie()
        self.rotor0._stop_crazyflie()
        self.rotor1._stop_crazyflie()
        self.rotor2._stop_crazyflie()
        self.rotor3._stop_crazyflie()
        self.controller.stop_controller = True
        self.logger.stop()
        self.remoter.command.quit()
        self.remoter.command.destroy()



if __name__ == '__main__':

    frame = rotor_combined(folder_name='log_test_att_satt6', keyboard_mode='attitude')
    frame.input_update_thread.start()
    frame.control_thread.start()
    while not frame.remoter.stop:
        frame.remoter.command.update()
        frame.run()

    frame.stop_frame()



