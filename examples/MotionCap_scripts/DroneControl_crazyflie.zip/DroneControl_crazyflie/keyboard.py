import Tkinter as tk
import time
import threading

class keyboard_control():
	"""docstring for keyboard_control"""
	def __init__(self, control_mode='attitude'):
		self.command = tk.Tk()
		self.command.bind_all("<Key>", self.key_input)

		self.stop = False
		
		self.velocity = 0.1
		self.square_size = 1
		self.ang_v = 0.06
		self.tilt_max = 0.3
		self.pause_time = 3
		self.last_update = time.time()
		self.state = 0

		self.control_mode = control_mode
 		
 		self.roll = 0
 		self.pitch = 0
 		self.yaw = 0
		
		self.x = 0
		self.y = 0
		self.z = 0.1

		self.small_step = 0.05
		self.z_step = 0.05

	def key_input(self, event):
		key_press = event.keysym.lower()
		print(key_press)

		if self.control_mode == 'position':
			if key_press == 'control_l':
				self.z = min(self.z+self.z_step, 0.1)
				print(self.z)
			elif key_press == 'alt_l':
				self.z = max(self.z-self.z_step, -1)
				print(self.z)
			elif key_press == 'right':
				self.y += self.small_step
				print(self.y)
			elif key_press == 'left':
				self.y -= self.small_step
				print(self.y)
			elif key_press == 'up':
				self.x += self.small_step
				print(self.x)
			elif key_press == 'down':
				self.x -= self.small_step
				print(self.x)
			elif key_press == 'space':
				self.z = 0
				print(self.z)
			elif key_press == 'return':
		 		run_square_thread = threading.Thread(target=self.run_square, name='run_square')
				run_square_thread.start()
			elif key_press == 'escape':
				self.stop = True
		else:
			if key_press == 'control_l':
				self.z = min(self.z+self.z_step, 0.1)
				print(self.z)
			elif key_press == 'alt_l':
				self.z = max(self.z-self.z_step, -1)
				print(self.z)
			elif key_press == 'right':
				self.roll += self.small_step
				print(self.y)
			elif key_press == 'left':
				self.roll -= self.small_step
				print(self.y)
			elif key_press == 'up':
				self.pitch -= self.small_step
				print(self.x)
			elif key_press == 'down':
				self.pitch += self.small_step
				print(self.x)
			elif key_press == 'space':
				self.z = 0
				print(self.z)
			elif key_press == 'return':
		 		run_square_thread = threading.Thread(target=self.run_tilt, name='run_tilt')
				run_square_thread.start()
			elif key_press == 'escape':
				self.stop = True

	def run_square(self):
		state = 4
		last_update = time.time()
		while state > 0:
			current_time = time.time()
			dt = current_time - last_update
			last_update = current_time

			if state == 4:
				if self.x < self.square_size:
					self.x += self.velocity*dt
				else:
					self.x = self.square_size
					state = 3
			elif state == 3:
				if self.y < self.square_size:
					self.y += self.velocity*dt
				else:
					self.y = self.square_size
					state = 2
			elif state == 2:
				if self.x > 0:
					self.x -= self.velocity*dt
				else:
					self.x = 0
					state = 1
			elif state == 1:
				if self.y > 0:
					self.y -= self.velocity*dt
				else:
					self.y = 0
					state = 0
			time.sleep(0.1)
			print(self.x, self.y)


	def run_tilt(self):
		state = 7
		last_update = time.time()
		while state > 0:
			current_time = time.time()
			dt = current_time - last_update
			last_update = current_time

			if state == 7:
				if self.pitch < self.tilt_max:
					self.pitch += self.ang_v*dt
				else:
					self.pitch = self.tilt_max
					state = 6
			elif state == 6:
				time.sleep(self.pause_time)
				last_update = time.time()
				state = 5
			elif state == 5:
				if self.pitch > 0:
					self.pitch -= self.ang_v*dt
				else:
					self.pitch = 0
					state = 4
			elif state == 4:
				time.sleep(self.pause_time)
				last_update = time.time()
				state = 3
			elif state == 3:
				if self.pitch > -self.tilt_max:
					self.pitch -= self.ang_v*dt
				else:
					self.pitch = -self.tilt_max
					state = 2
			elif state == 2:
				time.sleep(self.pause_time)
				last_update = time.time()
				state = 1
			if state == 1:
				if self.pitch < 0:
					self.pitch += self.ang_v*dt
				else:
					self.pitch = 0
					state = 0
			time.sleep(0.1)
			print(self.pitch)



if __name__ == '__main__':
	remoter = keyboard_control(control_mode='position')
	while remoter.stop == False:
		remoter.command.update()
		time.sleep(0.1)

