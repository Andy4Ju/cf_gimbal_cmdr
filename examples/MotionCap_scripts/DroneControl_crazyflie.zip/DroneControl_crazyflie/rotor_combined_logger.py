import time
import os
import sys

class rotor_combined_logger():
	"""docstring for logger"""
	def __init__(self, folder_name='log_files'):
		self.folder_name = folder_name
		self.log_memory = [["timeStamp", "dt", 
							"agv_x", "agv_y", "agv_z", 
							"roll", "pitch", "yaw", 
							"vx", "vy", "vz", 
							"px", "py", "pz", 
						 	"roll_ref", "pitch_ref", "yaw_ref",
							"x_ref", "y_ref", "z_ref",
							"beta0_meas", "beta1_meas", "beta2_meas", "beta3_meas",
							"thrust0_ref", "thrust1_ref", "thrust2_ref", "thrust3_ref",
							"beta0_ref", "beta1_ref", "beta2_ref", "beta3_ref"]]

	def log_append(self, timeStamp, dt, 
						 agv_x, agv_y, agv_z, 
						 roll, pitch, yaw, 
						 vx, vy, vz, 
						 px, py, pz, 
						 roll_ref, pitch_ref, yaw_ref,
						 x_ref, y_ref, z_ref,
						 beta0_meas, beta1_meas, beta2_meas, beta3_meas,
						 thrust0_ref, thrust1_ref, thrust2_ref, thrust3_ref,
						 beta0_ref, beta1_ref, beta2_ref, beta3_ref):
		self.log_memory.append([timeStamp, dt, 
						 agv_x, agv_y, agv_z, 
						 roll, pitch, yaw, 
						 vx, vy, vz, 
						 px, py, pz, 
						 roll_ref, pitch_ref, yaw_ref,
						 x_ref, y_ref, z_ref,
						 beta0_meas, beta1_meas, beta2_meas, beta3_meas,
						 thrust0_ref, thrust1_ref, thrust2_ref, thrust3_ref,
						 beta0_ref, beta1_ref, beta2_ref, beta3_ref])

	def stop(self):
		try:
			# Create target Directory
			os.mkdir(self.folder_name)
			print("Directory \"" + self.folder_name +  "\" Created ") 
		except:
			# print("Directory " + self.folder_name +  " already exists")
			pass

		with open(self.folder_name + '/log_' + time.strftime("%m%d_%H%M%S") + '.txt', 'w') as filehandle:
			for listitem in self.log_memory:
				filehandle.write('%s\n' % listitem)
			
			
